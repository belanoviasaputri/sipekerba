<?php
// ...existing code from original header.php...
?>
<link rel="icon" href="/assets/dist/img/diskominfo-logo.png">
<link rel="stylesheet" href="/assets/plugins/bootstrap4/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/plugins/fontawesome-free/css/all.min.css">
<img class="logo" src="/assets/dist/img/logo2.png">
<img src="/assets/img/homepage.svg">